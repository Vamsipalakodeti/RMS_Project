﻿#region using directive
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
#endregion using directive

namespace RMS_TT
{
    public class Program
    {
        #region class level Variables
        static string c_GreatestProductCombination = string.Empty;
        static long c_GreatestProduct = 0;
        static int c_CombinationCounter = 0;
        #endregion class level Variables
        static void Main(string[] args)
        {
            
            //int[,] arg = { { 1, 2, 3,4 },{ 4, 5, 6,4 },{7,8,9,4} };
            int[,] arg = { { 8, 2, 22, 97, 38, 15, 0, 40, 0, 75 },
                           { 49, 49, 99, 40, 17, 81, 18, 57, 60, 87 },
                           {81, 49, 31, 73, 55, 79, 14, 29, 93, 71 },
                           { 52,70,95,23,4,60,11,42,69,24},
                           { 22,31,16,71,51,67,63,89,41,92},
                           { 24,47,32,60,99,3,45,2,44,75},
                           {32,98,81,28,64,23,67,10,26,38 },
                           {67,26,20,68,2,62,12,20,95,63 },
                           { 24,55,58,5,66,73,99,26,97,17},
                           { 21,36,23,9,75,0,76,44,20,45} };
            //Call the method to find product.
            long result = findproduct(arg, 3);

            Console.WriteLine("Total Combinations : " + c_CombinationCounter.ToString());
            Console.WriteLine("GreatestProduct Combination: " + c_GreatestProductCombination.ToString());
            Console.WriteLine("Greatest Product : " + c_GreatestProduct.ToString());
            Console.WriteLine("Press any key to exit...!!");

            Console.ReadLine();
        }
        /// <summary>
        /// This method will accept the grid and the length and generates the GreatestProduct and its Combination & total combinations available based on lenght.
        /// </summary>
        /// <param name="arggrid"></param>
        /// <param name="arglength"></param>
        /// <returns></returns>
        public static long findproduct(int[,] arggrid, int arglength)
        {
            #region Local varibles declaration                        
            long l_loopProduct = 1;
            int l_GridLenX = arggrid.GetLength(0);
            int l_GridLenY = arggrid.GetLength(1);            
            #endregion Local varibles declaration

            //Main loop based on X-axis
            for (int i = 0; i < l_GridLenX; i++)
            {
                //Secondary loop based on Y-axis
                for (int j = 0; j < l_GridLenY; j++)
                {
                    //This block is to loop through the horizontal(X-Axis) combinations and finding the greatest product available in each row & replace the previous greatest product if available
                    #region Horizontal
                    l_loopProduct = 1;
                    string l_currCombination = string.Empty;
                    int l_AvailYIndex = l_GridLenY - j;
                    if (l_AvailYIndex >= arglength)
                    {
                        int l_Currentloop = 0;
                        while (l_Currentloop < arglength)
                        {
                            l_loopProduct = l_loopProduct * arggrid[i, j + l_Currentloop];
                            l_currCombination = string.Concat(l_currCombination, "*", arggrid[i, j + l_Currentloop].ToString());
                            l_Currentloop++;
                        }
                        c_CombinationCounter++;

                        CheckGreatestProduct(l_loopProduct, l_currCombination); //Compare with existing product value
                                                                            
                        //Reset loop values to default
                        l_loopProduct = 1;
                        l_currCombination = string.Empty;
                    }
                    #endregion Horizontal

                    //This block is to loop through the Vertical(Y-Axis) combinations and finding the greatest product available in each Column & replace the previous greatest product if available
                    #region Vertical
                    int l_AvailXIndex = l_GridLenX - i;
                    if (l_AvailXIndex >= arglength)
                    {
                        int l_Currentloop = 0;
                        l_loopProduct = 1;
                        l_currCombination = string.Empty;
                        while (l_Currentloop < arglength)
                        {
                            l_loopProduct = l_loopProduct * arggrid[i + l_Currentloop, j];
                            l_currCombination = string.Concat(l_currCombination, "*", arggrid[i + l_Currentloop, j].ToString());
                            l_Currentloop++;
                        }
                        c_CombinationCounter++;                        

                        CheckGreatestProduct(l_loopProduct, l_currCombination); //Compare with existing product value
                        //Reset loop values to default
                        l_loopProduct = 1;
                        l_currCombination = string.Empty;
                    }
                    #endregion Vertical

                    //This block is to loop through the diagonal combinations and finding the greatest product available with the current reference point & replace the previous greatest product if available
                    #region Diagonal
                    l_loopProduct = 1;
                    l_currCombination = string.Empty;
                    int YIndex = l_GridLenY - j;
                    int XIndex = l_GridLenX - i;
                    if (YIndex >= arglength)
                    {
                        if (XIndex >= arglength)
                        {
                            int currentloop = 0;
                            while (currentloop < arglength)
                            {
                                l_loopProduct = l_loopProduct * arggrid[i + currentloop, j + currentloop];
                                l_currCombination = string.Concat(l_currCombination, "*", arggrid[i + currentloop, j + currentloop].ToString());
                                currentloop++;
                            }
                            c_CombinationCounter++;

                            CheckGreatestProduct(l_loopProduct, l_currCombination); //Compare with existing product value
                            //Reset loop values to default
                            l_loopProduct = 1;
                            l_currCombination = string.Empty;
                        }
                    }
                    #endregion Diagonal
                }
            }            

            return c_GreatestProduct;
        }        
        /// <summary>
        /// This method compares the GreatestProduct value with the existing value and updates accordingly.
        /// </summary>
        /// <param name="argLoopProduct"></param>
        /// <param name="argLoopCombination"></param>
        private static void CheckGreatestProduct(long argLoopProduct, string argLoopCombination)
        {
            if (c_GreatestProduct < argLoopProduct)
            {
                c_GreatestProduct = argLoopProduct;                
                c_GreatestProductCombination = argLoopCombination;                
            }

        }
    }
}